﻿using System;

namespace Strings
{
    class Program
    {
        static void toggleChars(char[] str)
        {
            for (int i = 0; i < str.Length; i++)
            {
                if (str[i] >= 'A' && str[i] <= 'Z')
                {
                    str[i] = (char)(str[i] + 'a' - 'A' + 1);
                    if(str[i] == '{')
                    {
                        str[i] = 'A';
                    }
                }
                else if (str[i] >= 'a' && str[i] <= 'z')
                {
                    str[i] = (char)(str[i] + 'A' - 'a' + 1);
                    if (str[i] == '[')
                    {
                        str[i] = 'a';
                    }

                }
            }
        }
        static void Main(string[] args)
        {
            string str1 = Console.ReadLine();
            char[] str = str1.ToCharArray();
            toggleChars(str);
            Console.WriteLine("String after toggle ");
            Console.WriteLine(String.Join("", str));
        }
    }
}
