﻿using System;

namespace Strings
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter The Strine");
            string total = Console.ReadLine();
            int l, alp = 0, dig = 0, i = 0;
            l = total.Length;
            while (i < l)
            {
                if ((total[i] >= 'a' && total[i] <= 'z') || (total[i] >= 'A' && total[i] <= 'Z'))
                {
                    alp++;
                }
                else if (total[i] >= '0' && total[i] <= '9')
                {
                    dig++;
                }
                i++;
            }

            Console.Write("Number of Alphabets in the string is : {0}\n", alp);
            Console.Write("Number of Digits in the string is : {0}\n", dig);
        }
    }
}
